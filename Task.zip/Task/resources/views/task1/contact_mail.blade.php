<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Email</title>
</head>

<body>
    <table>
        <tr>
            <thead>Name*</thead>
            <td>{{ $contact_data['name'] }}</td>
        </tr>
        <tr>
            <thead>Phone no*</thead>
            <td>{{ $contact_data['phone'] }}</td>
        </tr>
        <tr>
            <thead>Email*</thead>
            <td>{{ $contact_data['email'] }}</td>
        </tr>
        <tr>
            <thead>Message*</thead>
            <td>{{ $contact_data['message'] }}</td>
        </tr>
        {{-- <tr>
            <thead>Name*</thead>
            <td>{{ $contact_data['name'] }}</td>
        </tr> --}}

        <p>Thank you</p>
        
    </table>
</body>

</html>
