<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Contact-us Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>
    <div class="container">

        <div class="card-header bg-primary">
            <h3 class="text-white">Laravel 9 Contact US Form</h3>
        </div>

        <div class="card-body">

            <?php if(session()->has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('success')); ?>

                </div>
            <?php endif; ?>

            <form action="<?php echo e(url('sendMail')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row">

                    <div class="mb-3">
                        <label class="form-label">Name*</label>
                        <input type="text" class="form-control" placeholder="Enter email" name="name">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Phone no*</label>
                        <input type="number" class="form-control" placeholder="Enter phone-no" name="phone">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email address*</label>
                        <input type="email" class="form-control" placeholder="Enter email" name="email">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Message*</label>
                        <textarea type="text" class="form-control" rows="3" name="message"></textarea>
                    </div>
                    
                    
                    <div class="mb-3">
                        <button type="submit" class="btn btn-success"
                            style="width: 80%; margin-left: 10%;">Submit</button>
                    </div>
                </div>
            </form>
        </div>

    </div>
</body>

</html>
<?php /**PATH D:\Laravel\Task\resources\views/task1/contactPage.blade.php ENDPATH**/ ?>