<?php

namespace App\Http\Controllers;



use App\Models\Contact;
use Illuminate\Http\Request;
use App\Mail\ContactFormMail;
use Illuminate\Support\Facades\Mail;




class MailController extends Controller
{
    public function contact()
    {
        return view('task1.contactPage');
    }

    public function sendMail(Request $request)
    {


        $this->validate($request, [

            'name' => 'required',
            'phone' => 'required',
            'email' => 'required|email',
            'message' => 'required'
        ]);

        // $contact_data = array(
        //     'name' => $request->name,
        //     'phone' => $request->phone,
        //     'email' => $request->email,
        //     'message' => $request->message
        // );
        // $contact_data->save();

        $contact_data = new Contact();
        $contact_data->name = $request->name;
        $contact_data->phone = $request->phone;
        $contact_data->email = $request->email;
        $contact_data->message = $request->message;
        $contact_data->save();

        $user = $request->email;
        // dd($contact_data);


        Mail::to($user)->send(new ContactFormMail($contact_data));
        return redirect('/contact')->with('success', 'Email sended successfully');


    }
}